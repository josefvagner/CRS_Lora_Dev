SX1280RF1ZHP ReadMe.txt


Important Notice for SX1280RF1ZHP Evaluation Module - PCB Version: PCB_394V02A


N.B. 1k resistor values validated at 5MHz SPI clock speed only (For higher clock speeds resistance value may be reduced).


� Semtech 2018